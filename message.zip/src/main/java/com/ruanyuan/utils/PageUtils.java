package com.ruanyuan.utils;
/**
 * Page��ҳ������
 * @author LiWenJing
 *
 */
public class PageUtils {
	//��ǰҳ
	private Integer page;
	//ÿҳ��ʾ������
	private Integer limit;
	//��������
	private Integer count;
	//start=(page-1)*limit �ڼ�ҳ��ʼ �����5ҳ��ÿҳ5�� ��5-1��*5=20 �ӵ�20�����ݿ�ʼ
	private Integer start;
	//״̬��
	private Integer code=0;
	//��ʾ��Ϣ
	private String msg="";
	//����
	private Object data;
	//�޲ι��췽��
	public PageUtils() {
		super();
		// TODO Auto-generated constructor stub
	}
	//page��limit���вι���
	public PageUtils(Integer page, Integer limit) {
		super();
		this.page = page;
		this.limit = limit;
	}
	public PageUtils(Integer count, Object data) {
		super();
		this.count = count;
		this.data = data;
	}
	public PageUtils(Object data) {
		super();
		this.data = data;
	}
	@Override
	public String toString() {
		return "PageUtils [page=" + page + ", limit=" + limit + ", count=" + count + ", start=" + start + ", code="
				+ code + ", msg=" + msg + ", data=" + data + "]";
	}
	public Integer getPage() {
		return page;
	}
	public void setPage(Integer page) {
		this.page = page;
	}
	public Integer getLimit() {
		return limit;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public void setLimit(Integer limit) {
		this.limit = limit;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public Integer getStart() {
		return start=(page-1)*limit;
	}
	public void setStart(Integer start) {
		this.start = start;
	}
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
}
