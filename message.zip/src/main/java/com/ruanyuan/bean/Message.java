package com.ruanyuan.bean;
/**
 * Messageʵ����
 * @author LiWenJing
 *
 */
public class Message {
	//����id
	private Integer messId;
	//��������
	private String messName;
	//��������
	private String messContent;
	//����ʱ��
	private String messTime;
	//�����
	private Integer messClicks;
	//���ظ�ʱ��
	private String messLMT;
	//��������
	private Integer messCount;
	//�����û� ��� User�����
	private User messUser;
	//���ظ��û� ��� User
	private User replyUser;
	//get��set����
	public Integer getMessId() {
		return messId;
	}
	public void setMessId(Integer messId) {
		this.messId = messId;
	}
	public String getMessName() {
		return messName;
	}
	public void setMessName(String messName) {
		this.messName = messName;
	}
	public String getMessContent() {
		return messContent;
	}
	public void setMessContent(String messContent) {
		this.messContent = messContent;
	}
	public String getMessTime() {
		return messTime;
	}
	public void setMessTime(String messTime) {
		this.messTime = messTime;
	}
	public Integer getMessClicks() {
		return messClicks;
	}
	public void setMessClicks(Integer messClicks) {
		this.messClicks = messClicks;
	}
	public String getMessLMT() {
		return messLMT;
	}
	public void setMessLMT(String messLMT) {
		this.messLMT = messLMT;
	}
	public Integer getMessCount() {
		return messCount;
	}
	public void setMessCount(Integer messCount) {
		this.messCount = messCount;
	}
	public User getMessUser() {
		return messUser;
	}
	public void setMessUser(User messUser) {
		this.messUser = messUser;
	}
	public User getReplyUser() {
		return replyUser;
	}
	public void setReplyUser(User replyUser) {
		this.replyUser = replyUser;
	}
	//toString����
	@Override
	public String toString() {
		return "Message [messId=" + messId + ", messName=" + messName + ", messContent=" + messContent + ", messTime="
				+ messTime + ", messClicks=" + messClicks + ", messLMT=" + messLMT + ", messCount=" + messCount
				+ ", messUser=" + messUser + ", replyUser=" + replyUser + "]";
	}
	
	
}
