package com.ruanyuan.bean;
/**
 * Repy��ʵ����
 * @author LiWenJing
 *
 */
public class Reply {
	//�ظ�id
	private Integer replyId;
	//�ظ�����
	private String replyContent;
	//�ظ�ʱ��
	private String replyTime;
	//����id
	private Integer replyMessId;
	//�ظ��û� ���
	private User user;
	//get��set����
	public Integer getReplyId() {
		return replyId;
	}
	public void setReplyId(Integer replyId) {
		this.replyId = replyId;
	}
	public String getReplyContent() {
		return replyContent;
	}
	public void setReplyContent(String replyContent) {
		this.replyContent = replyContent;
	}
	public String getReplyTime() {
		return replyTime;
	}
	public void setReplyTime(String replyTime) {
		this.replyTime = replyTime;
	}
	public Integer getReplyMessId() {
		return replyMessId;
	}
	public void setReplyMessId(Integer replyMessId) {
		this.replyMessId = replyMessId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	//toString����
	@Override
	public String toString() {
		return "Reply [replyId=" + replyId + ", replyContent=" + replyContent + ", replyTime=" + replyTime
				+ ", replyMessId=" + replyMessId + ", user=" + user + "]";
	}
	
}
