package com.ruanyuan.bean;
/**
 * User��ʵ����
 * @author LiWenJing
 *
 */
public class User {
	//�û�id
	private Integer userId;
	//�û�����
	private String userName;
	//�˺�
	private String userCode;
	//����
	private String userPassword;
	//�Ա�
	private String userSex;
	//get��set����
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserSex() {
		return userSex;
	}
	public void setUserSex(String userSex) {
		this.userSex = userSex;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userCode=" + userCode + ", userPassword="
				+ userPassword + ", userSex=" + userSex + "]";
	}
	
}
