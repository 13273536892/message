package com.ruanyuan.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ruanyuan.bean.Reply;
import com.ruanyuan.bean.User;
import com.ruanyuan.service.ReplyService;
import com.ruanyuan.utils.DateUtils;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class ReplyTest {
	@Autowired
	private ReplyService replyService;
	@Test
	public void addReply() {
		Reply reply=new Reply();
		reply.setReplyContent("11111");
		reply.setReplyMessId(1);
		reply.setReplyTime(DateUtils.getDate());
		User user=new User();
		user.setUserId(3);
		reply.setUser(user);
		replyService.addReply(reply);
	}
}
