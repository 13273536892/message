package com.ruanyuan.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ruanyuan.bean.User;
import com.ruanyuan.dao.UserDao;
import com.ruanyuan.service.UserService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class UserTest {
	@Autowired
	private UserService userService;
	@Autowired
	private UserDao userDao;
	/**
	 * ����ע��
	 */
	@Test
	public void RegisterUserTest() {
		User user=new User();
		System.out.println(user.getUserName());
		user.setUserName("userNaem");
		user.setUserCode("12323");
		user.setUserPassword("12344");
		user.setUserSex("��");
		System.out.println(user);
		System.out.println(user.getUserName());
		int count=userService.addUser(user);
		System.out.println(user.getUserName());
		System.out.println(count);
		if(count!=0) {
			System.out.println("���ӳɹ�");
		}else {
			System.out.println("����ʧ��");
		}
		System.out.println(user.getUserName());
	}
	/**
	 * �����˺������Ƿ���ȷ
	 */
	@Test
	public void loginUser() {
		User user1=new User();
		user1.setUserCode("1111");
		user1.setUserPassword("1111");
		User user=userDao.getUserByUser(user1);
		System.out.println(user);
	}
}
