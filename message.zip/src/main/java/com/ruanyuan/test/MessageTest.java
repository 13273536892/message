package com.ruanyuan.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ruanyuan.bean.Message;
import com.ruanyuan.dao.MessageDao;
import com.ruanyuan.service.MessageService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class MessageTest {
	@Autowired
	private MessageService messageService;
	@Autowired
	private MessageDao messageDao;
	/**
	 * ��ѯ����message
	 */
	@Test
	public void MessageAll() {
		List<Message> messagelist =messageDao.getMessageAll();
		for (Message message : messagelist) {
			System.out.println(messagelist);
		}
	}
	/**
	 * ��������
	 */
	@Test
	public void addMessage() {
		Message message=new Message();
		message.setMessClicks(0);
		message.setMessName("��������111222");
		message.setMessContent("20");
		message.setMessTime("2000-02-06");
		
		int count=messageService.addMessage(message);
		System.out.println(count);
		if(count>0) {
			System.out.println("���ӳɹ�");
		}else {
			System.out.println("����ʧ��");
		}
	}
	
}
