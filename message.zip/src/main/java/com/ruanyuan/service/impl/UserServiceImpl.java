package com.ruanyuan.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ruanyuan.bean.User;
import com.ruanyuan.dao.UserDao;
import com.ruanyuan.service.UserService;
/**
 * UserServiceʵ����
 * @author LiWenJing
 *
 */
@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao userDao;
	/**
	 * ע���û�
	 */
	public int addUser(User user) {
		// TODO Auto-generated method stub
		return userDao.addUser(user);
	}
	/**
	 * �����˺Ų�ѯ�û��Ƿ����
	 * @param userCode
	 * @return
	 */
	public User getUserByCode(String userCode) {
		// TODO Auto-generated method stub
		return userDao.getUserByCode(userCode);
	}
	/**
	 * �����˺������ѯ���ж��˺������Ƿ���ȷ��
	 * @param userCode
	 * @param userPassword
	 * @return
	 */
	public User getUserByUser(User user) {
		// TODO Auto-generated method stub
		return userDao.getUserByUser(user);
	}


}
