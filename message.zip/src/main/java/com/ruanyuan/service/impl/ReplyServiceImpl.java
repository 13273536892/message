package com.ruanyuan.service.impl;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ruanyuan.bean.Reply;
import com.ruanyuan.dao.ReplyDao;
import com.ruanyuan.service.ReplyService;
/**
 * ReplyServiceʵ����
 * @author LiWenJing
 *
 */
@Service
public class ReplyServiceImpl implements ReplyService {
	@Autowired
	private ReplyDao replyDao;
	/**
	 * �������Ա�Ų�ѯ�������µ����лظ�
	 * @param replyMessId
	 * @return
	 */
	public List<Reply> getReplyByMessId(Integer replyMessId) {
		// TODO Auto-generated method stub
		return replyDao.getReplyByMessId(replyMessId);
	}
	/**
	 * ���ӻظ�
	 * @param reply
	 * @return
	 */
	public int addReply(Reply reply) {
		// TODO Auto-generated method stub
		return replyDao.addReply(reply);
	}

}
